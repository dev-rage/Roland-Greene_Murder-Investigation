-- Q6 What does the forensic timeline say about the time and manner of death? 
SELECT * FROM `forensic event`; 